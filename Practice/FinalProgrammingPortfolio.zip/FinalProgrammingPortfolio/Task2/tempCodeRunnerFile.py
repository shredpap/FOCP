if valt[1]=="" or valt[0]=="" and valt=="":
            print("Error in data stream. Ignorning. Carry on.")
        else:
            count+=1
            data[valt[0]]=int(valt[1])